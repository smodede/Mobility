package com.test.zebrascanner;


public class Constants {
    public static final int BARCODE_RECIEVED = 1;
}
